# 这是个什么仓库

这里有女朋友生日/纪念日/情人节等等关键日子的**解决方案**，作为一个浪漫的程序员必不可少的惊喜仓库，内置解决方案如下：

- 生日解决方案: [birth-want-to-say](https://github.com/calebman/girlfriend-gift-collection/tree/master/birth-want-to-say)
- 聊天交互形式: [chat-want-to-say](https://github.com/calebman/girlfriend-gift-collection/tree/master/chat-want-to-say)

点击下方链接预览效果：

> 全部对移动版做好了适配，可使用 chrome 移动端模式进行预览查看效果。
> 

- 国内用户访问: [https://sg.chenjianhui.site/girlfriend-gift-collection/](https://sg.chenjianhui.site/girlfriend-gift-collection/)
- Github Pages: [https://calebman.github.io/girlfriend-gift-collection/](https://calebman.github.io/girlfriend-gift-collection/)